# Joined fleet, collection, and hiscore plan

Status: execution started on 2026-10-25. This is the current joined plan.
Older research remains evidence and history. It does not override current user goals.

## Goal and design

Build a self-sustaining owned fleet that prepares winning hiscore runs.
Keep wealth, useful collections, rare loot, best gear, quests, unlocks, and all 99s active.
Keep specialist wins and the main account's simultaneous 24-board challenge as separate targets.
An unsuccessful model is a gap to investigate, not permission to lower either target.

Use the existing TypeScript fleet, planner, practice server, and dashboard.
Do not build another controller. Scripts play. Model work improves scripts and plans.
Use subscriptions only. Do not add paid APIs.

## Ownership and evidence

- Preserve the existing dirty tree and the fleet under controller PID 34112. Recheck ownership before each operation.
- The earlier uptime chat is paused. This chat owns only the work explicitly started under this new instruction.
- Do not resume its launchers, change its goal status, or clear its failure records blindly.
- Keep the main account offline until the existing launch gates pass with real evidence.
- Trade only between owned accounts. No selling or player commerce. Use owned coins for permitted NPC supplies.
- Keep the 8 GiB free-memory floor. Reserve startup memory. Run one heavy qualification at a time.
- Let current production batches finish before temporarily withholding repeat admission for practice.
- Bind results to source hashes, actor, environment, tick rate, starting state, and raw logs.
- Practice proves tested conditions. Live pilots measure competition and deployment differences.
- Report unknown stock as unknown. Banked, carried, reserved, and delivered stock are different states.

## Goals and acceptance

| Goal | Evidence of progress | Finish or operating condition |
|---|---|---|
| Sustained fleet | Banked output, net costs, food coverage, failures, recovery | Repeated full cycles, refill, restart, and logout work without intervention |
| Wealth | Owned coins and useful bank value, minus operating costs | Growing reserves without starving supply or preparation |
| Useful and rare collection | Item IDs, quantities, dated holders, consumers | Coverage catalogue distinguishes available, unobtainable, and unproved items |
| Gear and unlocks | Owned usable equipment, completed prerequisites | Best available gear per intended role, proven routes to required content |
| Quests and 99s | Quest milestones and verified skill gains | All supported quests and skills completed on intended accounts |
| Specialist hiscores | Fresh board rules, targets, measured attempts | Verified rank 1 and a method to monitor and defend it |
| Main 24-board run | Whole-clock schedule, supplies, rehearsals, live conditions | All 24 ranks held together by the main account from the prepared run |
| Efficient operation | Useful output per tick, recovery costs, resource use | Improvements measured on matched work, with no unsupported speed claims |

## Existing paths and actual gaps

| Need | Existing path | Gap | Action |
|---|---|---|---|
| Role ownership and admission | scripts/fleet.ts, scripts/swarm.ts | Partial integration | Keep these as the runtime authority |
| Main-run requirements | packages/planner/src/haggis.ts suppliesFor | Missing stock reconciliation | Generate an advisory shortage report from selected-route supplies and dated owned banks |
| Bank evidence | packages/core/src/status.ts, packages/dashboard/collection.ts | Stale snapshots and unreserved stock | Expose age and holders. Never equate possession with staging |
| Food and funding | scripts/foodcourier.ts, courier-funding.ts, courier-purchase.ts | Current route prerequisites unproved | Qualify existing fixes, then recover exact stopped checkpoints |
| Fast practice | packages/practice/src/stack.ts, presets.ts, prove.ts | Conditions and coverage | Reuse these with fresh local actors and explicit competition scenarios |
| Hiscore targets and route | packages/planner/src/scout.ts, scout-cli.ts, haggis.ts | Stale targets and unmeasured inputs | Refresh validated snapshots, then rank experiments by gap reduction |
| Launch permission | scripts/haggis-gate.ts | Supply flag is not an item-level receipt | Keep false until real staging. Strengthen receipt validation before final launch |

## Ordered execution queue

### 1. Join production to preparation

- [x] Inspect branch, dirty files, worktree, current controller, and prior ownership notes.
- [x] Save this joined plan with all goals and evidence boundaries.
- [x] Add `scripts/preparation-report.ts` and `scripts/preparation-report.test.ts`.
- [x] Reuse `suppliesFor`, `haggisActivities`, `loadSnapshot`, and `haggisTravel` for the selected realistic route.
- [x] Reconcile only identified items in recent owned demo banks. Exclude practice and duplicate accounts.
- [x] Show dated holdings separately. Never count inventory, cargo, or old stock as fresh staged supplies.
- [x] Write `.practice/joined-plan/preparation.json` with `staged:false`. Do not write the main login gate or staging manifest.
- [x] Test unknown banks, stale/future timestamps, noted IDs, duplicate holders, and deficits. Run the report on actual status files.

### 2. Qualify the shared supply repair

- [x] Preserve the current courier source hashes and prior failed evidence.
- [x] Run focused courier funding, purchase, and resume checks.
- [x] Use a fresh local actor to exercise real NPC purchases with the production fare-reserve calculation.
- [x] Retain at least 60 coins. Confirm actual purchases, debit, logout, and persisted save. Test depleted stock separately.
- [x] Qualify combat-29 training on a local Bigpackage clone before training that live courier.
- [x] Recover Moneyshot from its actual Port Sarim checkpoint. Preserve Bigpackage's 2,150 fish notes.
- [x] Prove the exact 5,000-coin owned funding transfer in practice, then live. Preserve all other assets and verify both logouts.
- [x] Prove owned funding, safe return, and exact food delivery in practice, then live.
- [x] Prove repeated consumer production batches and refill from owned bank stock.
- [ ] Prove cook-to-courier replenishment and a repeated complete supply cycle.
- [x] Clear only the exact blocked courier epoch after accepted live recovery. Preserve unrelated failures.
- [ ] Extend food delivery to the combat consumer after proving its bank route and demand handshake.

### 3. Prepare all goals through useful stock

- [ ] Turn advisory shortages into reservations by consumer, item ID, quantity, holder, and destination.
- [ ] Keep operating food and fare reserves separate from main-run stock.
- [ ] Give each worker a bounded stock target and a next assignment. Preserve current batches during transition.
- [ ] Prove processing chains end to end: inputs, conversion, output, banking, and transfer.
- [ ] Advance gear, quests, and rare-drop routes when they unlock higher-value output or a preparation shortage.
- [ ] Keep coverage goals for rare items even when their immediate XP use is low. Record scarcity and actual source evidence.

### 4. Keep hiscore work active

- [x] Refresh all supported board targets with response validation and explicit timestamp units. Recheck before each attempt.
- [ ] Track each board's rule, leader, demonstrated time, model gap, supply needs, and next experiment.
- [ ] Measure route segments with three matched runs before rate claims.
- [ ] Test crowded resources, shared shops, target contention, failed trades, and restart recovery in practice.
- [ ] Measure the live difference in bounded pilots. Record player load and competing actors where observable.
- [ ] Update planner inputs from evidence. Do not copy optimistic empty-world rates into live plans.
- [ ] Prepare specialist attempts without presenting them as proof of the main account's shared clock.
- [ ] Rehearse the whole main route with real staged inputs and handoffs before final launch.

The next hiscore experiments must address shared-clock constraints, not just average production speed:

1. Verify the clock start and XP-credit rules against current server source and a fresh practice actor. Cooking's current 20-tick target precedes the model's 35-tick arrival at the kitchen. Faster late activities alone cannot close that early deadline.
2. Test early cooking, fletching, and crafting handoffs together with exact inventories and action timing. Retain each board's completion tick and the overall clock. Use three matched repetitions before changing rate inputs.
3. Rank supported overlapping actions and route changes by their effect on both individual deadlines and the 8,950-tick Overall gap. Treat an unproved mechanic as an experiment, not a scheduled saving.
4. Measure the selected route under resource and trade contention, then pilot that segment live. Preserve the main account for the fully prepared attempt.

Shared outputs keep the other goals moving: fish supports combat and wealth workers; their coins and drops support gear, quest inputs, and main-run supplies. Track rare-item coverage separately so profitable routine output does not hide missing collections. This dependency order does not mean every account should run every goal at once.

Clock source review: `World.ts:692` increments player playtime and `Player.ts:1905` stamps it when the base level rises. Player saves retain playtime and level timestamps. The older `research/cooking-board.md` login-wine experiments measured session ticks with preloaded banks; they do not include the complete fresh-account staging clock or prove the current 20-tick target. Include that distinction in the next experiment.

`current-levers.txt` reruns the current planner against the refreshed targets. Default Overall remains 44,866 ticks, 8,950 late. All optional mechanisms together model 44,562 ticks, still 8,646 late; this comparison is not approval to use them. Older `research/gap-closers.md` totals no longer describe the current model. The current model already credits external stun-pack, quest, and mining measurements. Reproduce the high-impact dependencies under our client and practice conditions before treating them as live rates. Additional savings must improve on those credited inputs, not count them twice.

### 5. Operate and improve

- [ ] Show shortages, stock reservations, blocked routes, and board gaps on the existing dashboard.
- [ ] Reserve capacity for the next useful practice experiment while proven live workers produce.
- [ ] Choose work by dependency impact, then measured bottleneck, risk, and cost. Do not optimise online count alone.
- [ ] After each batch, record actual goal movement here or in the existing evidence receipt. Avoid duplicate status documents.
- [ ] Review rare collection, quests, gear, and hiscores every planning cycle so food repairs do not permanently replace them.

## Current blockers and next actions

| Blocker | Owner | Next evidence |
|---|---|---|
| Courier needs replenishment and repeat proof | This execution, bounded stages | Training, recovery, funding, and actual delivery passed; exact failure repairs accepted; next observe production and prove refill |
| Fire Giant worker blocked after a failed repeat | Existing failure retained | Diagnose exact failed fight, then banked kill and replenishment proof |
| Main preparation has no item-level staging | This execution | Advisory shortage report, then reservations and transfer receipts |
| Board targets require recurring comparison | Planning lane | All 24 now captured; recheck before attempts, without authorising main login |
| Some model inputs remain unmeasured | Practice lane | Ranked matched-run experiments with raw results |
| Woodpecker stopped under live rock contention | Mining lane | Retain epoch 1792972599531; reproduce disappearing targets with competing practice actors before retry |

## First-batch record

The first batch adds an advisory stock report. It does not change production job assignments or main login permission.

Run `bun scripts/preparation-report.ts .practice/joined-plan/hiscores.json` from the repo root.
The report uses dated bank evidence from owned accounts. It excludes the reserved main account.
It matches observed item names and IDs. Missing names or ambiguous IDs stay unresolved.
It recognises the verified Feather and Headless arrow plural aliases. Other aliases and recipe substitutions remain unresolved.
Quantities come from the selected model route. They remain planning inputs, not proven final requirements.

Results recorded in `.practice/joined-plan/`:

- `preparation.json`: 72 model supply rows. Coverage changes as bank observations age. The first batch covered 17 rows. None are declared staged.
- `hiscores.json` and `boards/*.html`: all 21 time-ranked boards fetched and parsed. Pages confirm 400 ms normalised ticks.
- `main-route.txt`: fresh-target model. Overall is 44,866 ticks against 35,916, a gap of 8,950. This is not a measured run.
- Equipment, Bank, and Runite were subsequently refreshed in `value-targets.json` with raw pages retained. Equipment leader nickai3: 1,366,450 gp. Bank leader nickai3: 17,238,054,463 gp. Runite leader xulvexi: 2,454 all-time, 1,950 weekly, 132 daily ores. The model's no-clock rows do not prove rank wins.
- `practice-shop-proof.json`: actual local NPC purchases at 150 ms ticks. Both buyers started with 84 coins.
- Stocked buyer: seven feathers, 14 coins spent, 70 retained, 24 script ticks.
- A second local actor bought 950 feathers from the same shop. The world was not reset.
- Depleted-shop buyer: two feathers, 24 coins spent, 60 retained, 15 script ticks.
- All three local actors logged out. Persisted saves matched reported coin and feather counts.
- This proves the production reserve calculation under these shop conditions. It does not prove the full courier script or live route.
- Practice stopped. The runner restored the prior admission floor and repeat settings. Existing live actors were not forced out.
- `checks.log`: 63 focused tests passed across the report, planner, and courier dependencies.
- `source-check.json`: full TypeScript check passed. The temporary memory reserve was restored to 8 GiB.
- Fleet validation passed for 23 accounts and 17 enabled accounts. The SDK pin check passed for b565f2d9.
- Independent review found case-variant duplicate owners could double-count stock. The regression failed first, then passed after deduplication.

## Courier qualification and planner integration

- `training-proof.json`: a fresh local clone of Bigpackage reached combat 29 and returned to Draynor in 1,077 script ticks.
- The clone took no damage. Every starting item remained, including 1,232 trout notes and 918 salmon notes.
- The saved character file confirms the final items and return position. This is local proof with random events disabled.
- The practice server stopped and the prior fleet admission settings were restored.
- The validated 21-board snapshot now feeds `research/hiscores-live.json`. Its previous contents are preserved in `hiscores-before-publish.json`.
- `dashboard-targets.json` confirms the running dashboard API on port 3100 reads the new Quest Points leader and the Overall gap.
- Two explicit item-name aliases prevent false shortages for feathers and headless arrows. Their new regression failed before the fix.
- `checks-training-turn.log`: 70 focused tests passed after that change.
- `training-check/gate.json`: 688 tests passed, 3 skipped, and zero failed. TypeScript passed. The gate binds the training source.
- `native-training-proof.json`: Bigpackage reached combat 29 in 1,278 script ticks, returned to Draynor at 27/27 HP, preserved all assets, and logged out. Its original delivery failure remains blocked until delivery acceptance.
- Moneyshot can fund the courier from the east side. Do not train or return it across the island unless its next job needs that route.

Live training passed after the actual bank, kit, position, health, and combat level matched the practice baseline.
The runner restored the 8 GiB admission floor. Production repeat flags remained unchanged.
`native-competition.json` records a short public observation with five to seven players near the chicken pen. This does not prove each player competed for targets or establish a general speed multiplier.
Next execution: prove Moneyshot's short east-side bank and healing route locally, then recover funding and prove food delivery.

The first east-recovery practice admission reached its 360-second deadline before the host had 11 GiB free. No practice server or actor started. `east-practice-admission-failed-1.json` retains this failed admission; it is not a route failure. The runner restored the 8 GiB floor and all five temporary repeat holds. Moneyshot remained offline and unchanged during that attempt.

The second admission used current mining batch progress to add Woodpecker and OreElse to the temporary repeat holds. All current batches were allowed to finish. The failed first receipt is preserved as `east-practice-admission-failed-1.json`.
`east-practice-proof.json` now accepts local clone flrecxlsc01: 110 ticks from Port Sarim to Draynor, one owned shrimp consumed, HP10, and every other item preserved in the saved character file, including 21,046 total coins. Logout succeeded; the practice stack stopped; all seven repeat settings and the 8 GiB floor were restored.
`east-native-proof.json` accepts Moneyshot's same route live: 119 ticks, full HP10, exactly one shrimp consumed, all other items and 21,046 coins preserved, clean logout at Draynor. The original stop marker was archived for this bounded operation and restored afterward. The native reserve restored the 8 GiB floor. Next: prove the owned 5,000-coin transfer to Bigpackage, then the courier delivery and repeat cycle. Neither original courier nor combat failure was cleared.

`funding-practice-proof.json` accepts the 5,000-coin transfer on two local clones in 46 ticks. The donor retained 16,046 total coins; the receiver held 5,004. Actual saved files prove every other item unchanged, including all 2,150 fish notes. Both actors logged out and the practice stack stopped. The initial checker expected two separate logout lines; the runtime emits one line containing both results. `funding-practice-first-check.json` retains that failed checker result. `audit-funding-proof.ts` independently checks the saved deltas, current source hashes, exit status, and both successful logouts; its regression rejects a missing or failed logout. Live funding remains a separate acceptance step.

`funding-native-proof.json` now accepts the same transfer live in 48 ticks. Actual before/after bank, equipment, and inventory observations prove Moneyshot has 16,046 total coins and Bigpackage has 5,004. Every other item is unchanged; both actors retain full health and logged out. The runner restored the 8 GiB floor and Moneyshot's original stop marker. The courier's blocked epoch remains unchanged. Next: prove the funded courier's island return and actual consumer delivery in practice, then live; follow with replenishment and repeat-cycle acceptance.

`delivery-practice-proof.json` accepts the actual production courier's return from Draynor and delivery to a clone of Pocketrocket. It took 291 courier ticks, spent 60 coins on two fares, delivered 159 trout, and retained 1,991 fish notes and 4,944 coins. The recipient banked the notes and reached 160 food. Actual saved files account for both actors' assets; both stayed at full health and logged out. The practice server stopped and all temporary fleet settings were restored.
The first live preflight refused before login because the controller's demand check displayed `waiting offline` ahead of the retained blocked record. `delivery-native-preflight-failed-1.json` preserves the result. The runner now accepts that inactive display only alongside the exact unchanged failure epochs and an offline public roster; it still rejects `running` and `starting`. The new bounded live attempt must pass before either failure is repaired.

On 2026-10-26, `delivery-native-proof.json` accepted the same live route: 311 courier ticks, 60 coins in fares, 159 trout delivered and banked, both actors at full health, and both logged out. Bigpackage retained 1,991 fish notes and 4,944 coins. Pocketrocket reached 160 food; nonfood assets remained unchanged. One failed dialog attempt recovered through the existing retry.
`delivery-release.json` records controller-accepted repairs for Pocketrocket epoch 1792969020936 and Bigpackage epoch 1792964446162. Mightyrod's unrelated block remains unchanged. The controller now admits Pocketrocket when memory permits and keeps the courier offline until fresh food demand exists. This is not yet proof of sustained replenishment or a repeated full cycle.

`production-after-delivery.json` verifies Pocketrocket resumed under controller 34112, banked its prior carried coins, withdrew food, and earned 8,700 additional coins by tick 642. This proves useful production after refill, not a full repeat cycle. Four hosted thieves remain stopped at the same bank with one fish each. The next practice batch tests their 159-fish refills together from Bigpackage's remaining cargo.
Woodpecker's new failure is retained: nine attempts spent 121 mining-wait ticks with no ore or XP; most selected rocks disappeared during approach. `mine-competition.json` records 74 public tick frames and eight roster observations with 9–13 players in the mine area. Nearby players are not all proven miners. Use the failed target positions and changing occupancy to design a contested-target practice test; do not clear the failure from an empty-world success.

Mining investigation separates selection from gear. Woodpecker is Mining 99 but holds a bronze pickaxe. The current selection prefers fewer adjacent players, then ore rotation, then distance; approach time may therefore lose targets to moving competitors. The queued experiment alternates three production-policy and three nearer-target samples with the same bronze kit, starting state, 120-tick budget, and one rune-pickaxe competitor. This isolates one mechanism; it does not reproduce the full live crowd.
The recorded non-main fleet banks and kits show no upgraded pickaxe. Source `pickaxes.obj` assigns bronze mining rate 7 and rune rate 2, used by `mining.rs2` to set action delay. Rune requires Mining 41. Nurmof's shared shop lists one rune pickaxe; actual live availability, price, safe procurement route, and owned transfer remain unproved. Test the gear improvement separately, then connect successful procurement to the collection and hiscore supply plans.

`preparation-mining-review.json` refines the priority: this selected main route needs only 12 copper ore, 12 tin ore, and 45 iron ore, against dated owned holdings well above those amounts. It still needs 741 gold ore and one rune pickaxe with no observed coverage. Preserve current mining batches, but qualify a gold-and-tool assignment before resuming indefinite mixed-ore output on the stopped miner. Keep an operating/collection reserve and do not claim the dated stock is staged. The contested-target experiment supplies reusable evidence; it is not a reason to keep an overfilled assignment forever.

`batch-practice-proof.json` accepts a bank-side delivery to clones of all four stopped thieves. The courier handed over 636 fish in 52 ticks; all five saved characters preserved their other assets and health and logged out. An initial waiting test was cancelled before actors started to correct the generated-name prefix check; `batch-preflight-cancelled.json` retains that event.
`batch-native-proof.json` accepts the same live handoff in 62 courier ticks: each thief banked 159 fish and reached 160 food. Bigpackage retained 1,355 fish notes and 4,944 coins; no fares were needed. Exact combined asset totals, health, and all five logouts passed.
`batch-release.json` records four exact controller-accepted food-stop repairs. Admission was briefly held so the hosted group could restart together. Controller 34112 started supervisor 9824 and host 27420; all four accounts entered the game and began refilling their packs. The courier waits offline for fresh demand. All temporary settings are restored. Full production repeat and courier replenishment remain unproved.
In parallel with normal production, use the shortage report to plan reservations and choose the next board-gap experiment.
Do not enable a blocked live role from the purchase proof alone.

`production-completed-batch.json` records Pocketrocket completing its post-refill batch: 3,047 script ticks, 42,550 new coins, banked output, minimum HP 2, no death, and clean logout. This is one full batch, not full courier replenishment acceptance. After practice released its reserve, controller 34112 admitted the next Pocketrocket batch at epoch 1792974602905. The four hosted thieves remained running.

`mine-comparison-proof.json` is a failed qualification. All seven local actors logged out, but the competing miner filled its pack: rival output per sample was 21, 4, 0, 0, 0, 0. The intended drop path used inventory options rather than the supported explicit drop action. The second worker also gained one iron ore and 875 XP between sample measurement and its persisted logout state. Keep both raw outcomes; do not infer a speed improvement or clear Woodpecker's stop. `mine-comparison-audit.json` records these failures and verifies restoration of the 8 GiB floor and all six temporary repeat holds.

Before rerunning, use the existing explicit `dropItem` action and verify each inventory decrease. Require observed rival progress in every sample. Stop mining at the sample boundary, record any settlement output separately, and reconcile the final saved state without treating extra logout work as measured output. Preserve the first experiment unchanged. Then qualify the gold/tool assignment against the preparation shortage; avoid extending mixed-ore production merely because a policy test exists.

The corrected comparison is running as `practice-mine-comparison-v2.ts` (parent PID 5560, tool session 26064). It uses separate files so the first failed experiment stays intact. It sends the explicit ore-drop action and requires an observed decrease, rejects samples with no rival output, cancels worker mining with a walk, and records settlement output separately from the timed sample. Both entry points passed a Bun parse/build check; actual game acceptance is still pending. The runner owns the temporary 12 GiB admission floor and six repeat holds until its `finally` restores them. Current batches continue to finish naturally.

Tool procurement can reuse `scripts/shop-buyer.ts`'s existing Nurmof location and Falador bank route, plus its coin reserve and spending caps. Its current Nurmof profile targets all six pickaxe grades: do not launch that profile unchanged for a rune-only requirement, since depleted rune stock can redirect the purchase to another grade. A rune-only bounded qualification must prove the exact tool ID, actual debit, bank return, and health from the selected live buyer's real starting state. Shop source lists one rune pickaxe; this does not establish live availability or price. Fund from verified surplus coins after operating reserves, not the courier's food/fare float or the main's preparation stock.

Gold qualification now has a local-only actor, `.practice/joined-plan/gold-route-actor.ts`. It preserves the bronze-tool baseline, visits Draynor bank, attempts six gold ore at Rimmington (rocks 2098/2099 near 2976,3234), returns, and checks the exact bank increase and health. Gold ore ID 444 and Mining 40 are verified in the current item data and mining source. The actor passed a Bun parse/build check only; a fixture runner, full asset/save reconciliation, and actual local execution are still required before any live assignment. Source spawn data places seven level-14 scorpions around the Al Kharid gold rocks, so Rimmington is the first candidate to test for combat-13 Woodpecker. No safety or rate claim follows from these static facts.

Correction to the Nurmof route note: the existing buyer has shop/bank coordinates, but its movement helper calls `walkPath` without an explicit transport step. An underground round trip is not established by that profile. Reuse its purchasing and budget helpers; qualify the actual mine entrance and return using the existing transport machinery before live procurement.

`host-production-completed.json` accepts the four thieves' first full post-refill batches: mmtha0205 38,850 new coins; mmthv2350 41,150; Pocketpython 42,300; mmsmk1232 44,000. Combined new output is 166,300 coins. Each final result reports zero carried coins, no death, and a clean logout; the host reports 4/4 success and supervisor exit 0. This extends completed-batch evidence to all five recovered thieves, but does not prove the whole cook/courier replenishment loop. Their next repeats wait on the active practice admission reserve.

`.practice/joined-plan/practice-gold-route.ts` now wraps the gold actor with a fresh local clone of Woodpecker, source hashes, an 8 GiB operating floor, bounded admission/runtime, stack ownership checks, exact saved asset totals, banked gold, HP, XP, and logout checks. It passed Bun parsing/building. It has not run and must not overlap the active mining comparison or its temporary fleet settings.

`mine-comparison-v2-proof.json` records an admission failure on 2026-10-26: the 900-second window ended below the 12 GiB startup threshold. No practice actors or stack started. The runner restored the 8 GiB floor and six repeat settings; this is not a mining-policy result. The smaller gold qualification was then started under its own 11 GiB admission requirement. It remains unproved until its runtime and saved-state checks pass.

`food-loop-stock-review.json` retains dated cook banks (763 and 1,625 cooked fish at capture) and the courier's 1,355 fish notes, plus cooking log progress. The source confirms courier admission also needs a fresh low-food consumer. No forced collection is warranted by those stocks alone. The cooks' low-coin fallback gathered feathers and resumed cooking; their displayed restocking phase alone was not evidence of a stall.

The selected air-to-nature Runecraft route inherited 4,213 essence from the older law-altar route. The current level curve and source altar XP show this is insufficient: even 4,213 nature essence gives only 947,925 XP, below 998,458 for level 99, before accounting for the air stage. The route patch now requests 4,536 essence (27-slot packs through air level 44, then nature), plus explicit air and nature talismans. This covers the modelled crafter inputs; helper access and replenishment still require separate qualification.

`runecraft-supply-check.json` binds the correction to source hashes. The regression failed first (4,213 versus required 4,536); 35 planner/report tests then passed, and TypeScript passed. `preparation-runecraft-corrected.json` has 73 supply rows, remains unstaged, and separates dated holdings: Shaftsinker's last bank observation contains 14,487 essence and one air talisman, while nature talisman coverage is unresolved. The 1,330-tick helper-fed Runecraft estimate is not runtime evidence or a verified rank win.

`gold-route-proof.json` now accepts the actual local gold route: 900 script ticks, six gold ore mined and banked, 9,750 Mining XP, full HP 15, clean logout at Draynor (3092,3245), and exact preservation of every other saved item. The test used Woodpecker's copied starting checkpoint, skills, and bronze pickaxe. The practice stack stopped; the runner restored the 8 GiB floor and all six repeat settings. This proves the empty-practice route only. Next qualify a bounded live attempt against the unchanged checkpoint and retained failure epoch; do not clear the old mixed-mine failure or enable indefinite mining from this proof alone.

`production-repeat-completed.json` records Pocketrocket's second full post-refill batch: 46,200 new coins banked, zero carried coins at completion, no death, clean logout, supervisor exit 0. This proves controller repetition and refill from its own bank. Cook-to-courier replenishment remains open.

The bounded live gold pilot is prepared in `gold-native.ts` and `gold-native-actor.ts`. Before launch it requires the accepted practice hashes, identical route-body text, the unchanged Woodpecker snapshot and failure epoch, and an offline public roster. After login it checks actual position, skills, inventory, and equipment against practice. Acceptance requires fresh bank/status observations, the exact gold-only asset increase, XP, full health, and logout. Both native entry points passed Bun parsing/building. No controller repair is part of this pilot.

The next gold upgrade candidate joins skills, unlocks, and useful output. Current source `skill_crafting/scripts/crafting_guild/crafting_guild.rs2` requires Crafting 40 and a worn brown apron; the world data lists seven gold rocks inside the guild. At the configured 25x XP rate, spinning 16 wool reaches Crafting 10, then 40 flax reaches Crafting 40 (16,000 XP versus the 15,789 threshold), producing 16 balls of wool and 40 bowstrings. These are source-derived input counts, not a qualified route or speed claim. Reuse existing spinning and transport code, prove the full bank/spin/equip/entry cycle in practice, and compare actual output under competition before changing the worker assignment.

`flax-target-covered.json` records a bounded assignment change: Ballspinner's current flax batch continues, but automatic repeats are disabled. Its recent bank observation held 17,790 flax, 2,159 bowstrings, and 40 wool, and Crafting was already 99. The selected main-route manifest requests no additional flax. These holdings cover the proposed 16-wool/40-flax unlock inputs before any transfer, but remain unstaged. The controller confirmed the same running batch with `repeat:false`; no stop marker or replacement job was sent. Future practice reservations must preserve this new repeat setting rather than restore all workers to true.

`gold-live-presence.json` contains eight public roster observations over 30 seconds: 22–23 players in the Rimmington mine region. Presence alone does not prove gold mining. During the bounded live pilot, Woodpecker reached three gold ore by script tick 897 at full HP 15; final banking and acceptance remained pending at that observation. The empty-practice rate must not be used as a live supply forecast.

The live Rimmington pilot failed its 1,800-tick bound. `gold-native-proof.json` and its raw log retain five gold ore gathered, full HP 15, clean logout, and 81.7% ledger idle ticks. The actor stopped at the mine with its five ore and bronze pickaxe intact; no successful banked production result is claimed. The wrapper restored its reserve. Do not promote this route or clear the old mixed-mine failure. The empty-practice success did not predict acceptable live output.

A separate bank-only recovery (`gold-recovery.ts`, `gold-recovery-actor.ts`) now uses the existing bounded `retreatOre` path to Draynor. It checks the failed pilot's exact held items and position before moving, performs no mining, and requires all five ore banked, no item loss, unchanged Mining XP, full health, fresh bank observations, and logout. Its outcome must be reported separately from the failed production pilot.

`flax-final-batch.json` verifies Ballspinner ended its current batch naturally with 287 flax banked, zero carried flax, no damage, and clean logout. The controller reports done with `repeat:false`; the stock-based assignment hold is now in effect.

`gold-recovery-proof.json` accepts the separate live bank-only recovery: all five owned gold ore banked in 78 recovery ticks, full HP 15, unchanged Mining XP, every other asset preserved, and clean logout at Draynor (3092,3245). The failed Rimmington production pilot remains failed and the old job block remains intact. The recovery restored the 8 GiB admission floor.

`gold-sites-presence.json` records seven simultaneous public snapshots: zero players adjacent to the seven source-mapped guild gold rocks, versus 1–6 adjacent to Rimmington's two gold rocks. This short observation supports choosing the guild as the next qualification candidate; it does not prove mining behaviour, access, or future competition.

`guild-chain-actor.ts` and `practice-guild-chain.ts` now qualify the joined unlock path: spin 16 wool and 40 flax, equip a brown apron, enter the guild at Crafting 40, mine six gold ore, and bank all products. The fixture explicitly adds 16 wool, 40 flax, and one apron to the copied bank; success is conditional on those inputs and is not live staging proof. Saved-state checks require exact material conversion, 16,000 Crafting XP, gold/Mining XP, full HP, and preservation of other assets. Both files passed Bun parse/build checks. The queued runner restores original repeat flags, including Ballspinner's deliberate false setting, rather than forcing all workers to repeat.

`guild-supply-review.json` records the separate input gap. Moneyshot has 1,831 banked flax at Draynor, beside Woodpecker; a bounded 40-flax transfer can reuse the owned payout path after practice proof. Preserve Moneyshot's stop marker and other assets. Ballspinner holds 40 wool at Seers. Compare that transport with collecting 16 wool near Lumbridge. The existing wool worker bootstraps coins by pickpocketing and is not an exact 16-wool procurement route. Woodpecker already has 24 banked coins; prove withdrawing and spending owned coins rather than adding combat risk. Varrock source lists one brown apron in each of two shared shops, but current live stock is unknown. The existing Thessalia buyer targets gloves, so it must not be launched unchanged for an apron. All three inputs remain unstaged; the conditional guild test does not close these gaps.

`guild-chain-proof.json` now accepts the conditional local chain on actor `flgldxdw901`: 2,303 ticks at a 150 ms practice tick, Crafting 1 to 40 (16,000 XP), 16 wool balls and 40 bowstrings banked, apron equipped, guild entered, and six new gold ore banked. The saved file confirms the exact input/output changes and every other asset. Health stayed at 15; logout succeeded. The runner stopped its practice stack and restored the 8 GiB floor and original repeat flags, including Ballspinner false. This single run proves the chain under supplied inputs, not a live production rate or completed procurement. Travel consumed 1,478 ledger ticks, so shorten bank travel only after a matched comparison. Next: qualify actual input delivery and procurement, then a bounded live guild trial; keep the earlier Rimmington failure and Woodpecker's old job block intact.

The flax transfer qualification reuses `preparePayout` with two unnoted loads of 20. Each load is banked before the next trade; both accounts' complete item totals must match the exact flax transfer. The local runner copies Moneyshot and Woodpecker without adding items. It checks saved totals, source hashes, health in the actor, and both logouts. Build checks passed; runtime acceptance is pending. Its temporary repeat holds restore each original value.

The first flax run failed its final checker: it called `bankObservation()` after closing the bank. That API returns null when the bank is closed (`inprocess.ts`). Both trades and logouts occurred; saved files show donor flax -40, receiver bank +40, and all other assets unchanged. The original failed receipt, actor, and logs remain intact. A separate v2 opens the bank for the final check and must pass a new practice run before live use. No live flax moved. The live v2 wrapper is prepared but has not run. A local-only 16-wool collector also builds; it uses the owned 24 coins for shears, removes pickpocketing and excess gathering, and still needs full practice asset/health validation.

`combat-block-review.json` records the latest retained Mightyrod failure from the production log. The worker banked safely with assets preserved and no death, but credited zero kills after 253 fight ticks and consumed eight salmon. This is not an empty-food block: the later dated bank observation has 331 salmon. Older successful single-kill receipts do not supersede the failed repeat. Qualify a gear or fight-time improvement and kill credit from the current checkpoint before clearing epoch 1792955012008. Keep later food-loop acceptance as a separate requirement.

The next gear candidate can reuse the current combat code: it already selects owned adamant sword 1287 ahead of bronze sword 1277. The dated Mightyrod checkpoint holds 5,000 coins. Current source gives the adamant sword a 2,080 base value and Varrock Swordshop a shared stock of two; its NPC is named Shop keeper, not Horvik. Prove the actual purchase price, exact sword ID, journey, health, and bank return before live procurement. Then compare matched fights and verify kill credit and repeat survival. Do not treat base value or source stock as a live quote or availability guarantee.

`flax-v2-practice-proof.json` accepts the corrected transfer in 100 donor ticks: 40 flax banked by the receiver, exact donor debit, all other saved assets preserved, full health, and both logouts. The first failed check remains retained. `flax-native-v2.ts` is now queued for the same owned live handoff, with outcome pending.

`stock-assignment-holds.json` changes only repeat flags and notes for Shaftmaker, Bigchopper, YewFirst and OreElse. All four current batches were still running afterward and may finish normally. Their automatic repeats are now deliberately false, like Ballspinner; future practice cleanup must preserve these values. The fresh report has 8,212 recent normal logs and 9,616 oak logs against selected-route direct needs of 27 and four. Even allowing four full sets of the route's 3,615 headless arrows from new logs requires only 964 further normal logs at 15 shafts per log. Existing shafts and headless arrows reduce that input further. Mixed ore holdings also exceed the selected copper/tin/iron needs; they are dated, not staged. Next qualify missing willow/maple/yew/magic logs and arrow assembly, plus the gold/tool assignment. These are stock-based assignment holds, not completed reservations or proof of a new role.

`flax-v2-native-proof.json` accepts the live handoff in 122 donor ticks: Woodpecker banked 40 flax; Moneyshot retained 1,791 flax and all 16,046 coins. All other item totals, skills and health remained unchanged. Both actors logged out. Moneyshot's original stop marker and the 8 GiB admission floor were restored; Woodpecker's old mining block remains intact. This closes the flax input delivery only. The 16-wool practice test now starts from Woodpecker's updated Draynor checkpoint with those 40 flax preserved, using owned coins for shears and no injected supplies. Its result is pending; the apron is still unprocured.

`wool-input-proof.json` accepts the next local step: buy one shears from owned coins, collect exactly 16 wool, and bank it in 741 actor ticks. Health stayed at 15; skills were unchanged; all other saved items, including the 40 flax, were preserved. Logout and stack cleanup succeeded. The 8 GiB floor and original repeat flags were restored. Live wool collection and apron procurement are still required before the previously proved guild-training chain can run with actual inputs.

`wool-native-proof.json` now accepts live collection: 16 wool banked in 814 actor ticks, one shears bought for one coin, minimum HP 15, unchanged skills, and all other assets preserved. Woodpecker logged out at Draynor with the shears held, pickaxe banked, 23 coins, 16 wool and 40 flax banked. The mining block remains intact. The apron test therefore also banks the shears and restores the pickaxe kit for the training chain. It copies actual stock and uses ten owned coins as the purchase limit. The first apron attempt failed before login because `runBotName` truncated its seven-character prefix; its failed receipt is retained. A separate v2 uses a shorter prefix, checks 20 generated names against the actor guard, and passes the Bun build check. Its actual NPC-purchase and return run is in progress.

`apron-input-v2-proof.json` accepts practice procurement: one brown apron bought for two coins and banked in 1,022 ticks, full health, unchanged skills, every other saved asset preserved, and only the bronze pickaxe left in inventory. The stack stopped and prior repeat settings were restored. `apron-native.ts` is now running the same body live, with an actual-bank baseline check, source hashes, offline roster, exact old mining block, and full item/health/logout checks. Its result is pending.

Before the live guild chain, test the prepared two-load variant (`guild-packed-actor.ts`, `practice-guild-packed.ts`). Equipping the pickaxe frees one inventory slot. Load one holds 16 wool plus 12 flax; process wool first to reach Crafting 10, then the flax. Load two holds 28 flax. This accounts for all 56 inputs in two trips instead of three. The wrapper requires actual owned input stock and injects nothing. It checks the same 16 wool balls, 40 bowstrings, Crafting 40, six gold ore, health and saved-item totals. Build and 20 generated-name checks pass; runtime and speed benefits remain unproved. Do not update timing inputs from this proposed saving.

`apron-native-proof.json` accepts live procurement in 1,134 actor ticks: one apron banked, two coins spent, full health, unchanged skills and other assets, pickaxe kit restored, and clean logout at Draynor. Woodpecker now has the actual 16 wool, 40 flax and apron, plus 21 coins; no main-account staging claim is made. The live ledger has 945 movement ticks versus 951 in practice, and 194 idle ticks versus 65. These observations do not establish an energy or competition cause. The server source defaults `NODE_INFINITE_RUN` to true; actual live configuration was not inspected. The two-load guild practice run has now started from the complete owned inputs. Its live wrapper is prepared but cannot run without that new passing proof.

The 2026-10-26 02:08 refresh is retained under `.practice/joined-plan/targets-20261026-0208/`, including all raw pages, previous published snapshot, and leader comparison. All 21 timed leaders are unchanged. `research/hiscores-live.json` now has the validated fresh snapshot; the planner still models Overall at 44,866 versus 35,916 ticks (8,950 late). Value-board targets are equipment 1,366,450 gp and bank 17,238,054,463 gp; the Runite groups show 2,463 all-time, 1,919 weekly and 121 daily. These are public targets, not owned results or wins.

`guild-packed-proof.json` accepts the actual-input two-load chain: 2,009 ticks, Crafting 40 at 16,000 XP, 16 wool balls and 40 bowstrings banked, six new gold ore banked, full health, exact saved assets, and logout. One 90-tick mining attempt timed out before later attempts produced the required ore. This is one qualification, not a matched speed comparison or a live rate. `guild-packed-native.ts` has now started the same bounded chain live. The old mixed-mine block remains intact. After accepted live results, qualify a bounded repeat gold assignment using the existing mining helpers; the current production `gather-ore.ts` only supports mixed ore and clay, so clearing its old block would not deploy the guild route.

Runecraft supply and rare-loot planning now have a concrete source constraint: `shared_droptables.rs2` lines 61–74 chooses chaos talismans when the credited player's `coordz(coord) > 6400`, otherwise nature talismans, on the members-only jewel branch. Waterfall Fire Giants therefore do not cover the nature-talisman gap through this table. Keep their gear/rare-loot goal, but qualify a surface drop source separately. Surface moss giants are a candidate: their direct jewel branch is 4/128; the nature branch is 4/128 without a wealth ring and without the completed Legends substitution. The resulting 1/1,024 probability is a source-derived per-kill model, not a delivery deadline or measured rate. Actual surface access, survival, kill credit, loot pickup, banking, and competition remain unproved. A search found no named nature talisman in the current status files; this is not proof that every owned bank is empty.
